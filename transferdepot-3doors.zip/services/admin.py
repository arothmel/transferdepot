from flask import Blueprint, jsonify
import time

# Admin door at /admin
admin_bp = Blueprint("admin", __name__, url_prefix="/admin")

# Health check (machine-friendly)
@admin_bp.route("/healthz")
def healthz():
    return jsonify(ok=True, time=time.strftime("%Y-%m-%d %H:%M:%S"))

# Compat check (human-friendly)
@admin_bp.route("/compat")
def compat():
    return "<h1>Admin Compat</h1><p>Not connected yet</p>"
